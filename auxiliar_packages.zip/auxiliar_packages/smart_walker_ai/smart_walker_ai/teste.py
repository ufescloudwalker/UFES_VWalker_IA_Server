from langchain.embeddings import NomicEmbeddings

model = NomicEmbeddings(model_name="nomic-embed-text")
print(model)