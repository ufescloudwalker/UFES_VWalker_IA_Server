import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Path
from std_srvs.srv import Trigger

class PathPublisher(Node):

    def __init__(self):
        super().__init__("path_publisher")

        #Cria um serviço para detectar que um novo caminho foi planejado.
        self.srv = self.create_service(Trigger, 'reload_path', self.reload_path_callback)
        #Cria um subscriber para receber o caminho planejado.
        self.path_subscriber = self.create_subscription(Path, 'calculated_path', self.path_callback, 10)
        #Publica o caminho na forma de um tópico.
        self.setPath = self.create_publisher(Path, '/reference_path', 10)
        self.paths = Path()
        self.paths.header.frame_id = "odom"
        timer_period = 0.5  
        self.timer = self.create_timer(timer_period, self.timer_callback)

    def path_callback(self, msg):

        self.paths = msg  
        self.paths.header.frame_id = "odom"
        self.get_logger().info("Novo caminho recebido e armazenado.")

    def publish_path(self):

        if self.paths.poses: 
        # Filtra os pontos para publicar 
            filtered_path = Path()
            filtered_path.header = self.paths.header
            #reduz a quantidade pontos a serem usados para andador seguir por filtragem em n/2:  
            filtered_path.poses = [p for i, p in enumerate(self.paths.poses) if i % 3 == 0]

            self.setPath.publish(filtered_path)
            self.get_logger().info(f"Path publicado com {len(filtered_path.poses)} pontos filtrados.")
        else:
            self.get_logger().warn("Tentativa de publicar um path vazio!")

    def reload_path_callback(self, request, response):
        
        self.publish_path()
        response.success = True
        response.message = "Path atualizado com sucesso."
        return response

    def timer_callback(self):
        
        self.publish_path()

def main(args=None):
    rclpy.init(args=args)
    path_publisher = PathPublisher()

    try:
        rclpy.spin(path_publisher)
    except KeyboardInterrupt:
        pass
    finally:
        path_publisher.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
