from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.prebuilt import ToolNode
from langchain_core.tools import tool
from langgraph.prebuilt import tools_condition 
from langchain_ollama import ChatOllama
from langgraph.graph import StateGraph, MessagesState, START, END
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.callbacks.manager import CallbackManager
from langchain_core.prompts import ChatPromptTemplate, PromptTemplate
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from geometry_msgs.msg import Pose
from std_srvs.srv import Trigger
from std_msgs.msg import String
from std_srvs.srv import SetBool
from smart_walker_ai_msgs.action import LlmContextual


callback_manager = CallbackManager([StreamingStdOutCallbackHandler()])

# Carrega o modelo de LLM utilizado
LLM_model = ChatOllama(
    model="qwen2.5:32b",
    temperature=0.0,
    num_predict=1024,
    num_ctx=8094,
    callback_manager=callback_manager,
    seed=None,
)

#Modelo de prompt passado o llm.
prompt = ChatPromptTemplate.from_messages(
    [
        ("system", """
You are an intelligent assistant controlling a walker. With each interaction with the user, you check to see if there is a need to change the walker’s operating mode. The goal is to continuously identify the user's intent and adjust the navigation mode accordingly. The walker has two operating modes:

- **Free Navigation**: The user walks freely without assistance.
- **Assisted Navigation**: The user wants to be guided or assisted to reach their destination.

Whenever the user makes a request, check for a clear indication that the navigation mode needs to be changed. If so, use the mode decision tool to make the switch.

If the walker is in assisted navigation mode and the user states a destination, you should use the entire user input sentence to find an appropriate path to the destination. Use the path generation tool to calculate the route and guide the user to the requested location.

If the request is for assisted navigation and the user does not indicate a destination, you should ask or wait for more details about the desired location.

Always check all sentences to identify whether the user wants to change the operating mode. If the message is informal, respond in a friendly manner, but always taking into account the required operating mode.
"""),
        ("human", "{input}"),
    ]
)

chain = prompt | LLM_model

#Criação das ferramentas do agente:
@tool
def decision_function_mode(query: str) -> str:
    
    """
    Determines the appropriate operating mode for the walker based on the user's spoken commands.

    This function analyzes the user's input to identify whether the walker should operate in "Free Navigation" or "Assisted Navigation" mode.

    - **Free Navigation**: The user walks independently without guidance from the walker. This mode is ideal for users who are confident in their movement and do not require additional support.
    - **Assisted Navigation**: The walker provides guidance to the user, actively assisting in reaching a specified destination. This mode is designed for users who may have mobility challenges or require directional support.

    Args:
        query (str): The voice command provided by the user. Examples include:
                    - "I want to go to the cafeteria." (Assisted Navigation)
                    - "I'm good to walk on my own." (Free Navigation)

    Returns:
        walker operating mode determined by the interpretation of the user command.
    
    """

    query = query.lower()
    print(f"Value from llm: {query}")
    if "free navigation" in query or "free mode" in query:
        return "Free navigation"
    elif "assisted navigation" in query or "assisted mode" in query:
        return "Assisted navigation"  
    return "None" 

@tool
def create_path_for_navigation(query: str) -> str:
    """Generates a path for navigation based on the user's input"""
    return f"Caminho gerado para: {query}"  

#Criação do agente utilizado no controle do andador:

tools = [decision_function_mode, create_path_for_navigation]
llm_with_tools = LLM_model.bind_tools(tools)
sys_msg = SystemMessage (content= "You are a useful assistant in charge of controlling the operating mode of a smart walker based on the intentions extracted from the user's sentence. The walker has two operating modes: free navigation (where the user does not need your help to walk) or assisted navigation (where you can assist the user by creating a safe route to the destination point if requested). If during use the user talks to you about subjects other than navigation-related commands, just respond in a friendly manner.")


def reasoner (state: MessagesState):
    messages = state["messages"]
    result = [llm_with_tools.invoke([sys_msg] + messages)]
    return {"messages": result}


builder =StateGraph (MessagesState)
builder.add_node(reasoner)
builder.add_node ("tools", ToolNode(tools))
builder.add_edge(START, "reasoner")
builder.add_conditional_edges(
    "reasoner",
    # If the latest message (result) from node reasoner is a tool call -> tools_condition routes to tools
    # If the latest message (result) from node reasoner is a not a tool call -> tools_condition routes to END
    tools_condition,
)

builder.add_edge("tools", "reasoner")
agent= builder.compile()


class OllamaLLM(Node):
    def __init__(self) -> None:
        super().__init__("LLM_Control_Node")

        self.client_service = self.create_client(SetBool, "/admittance_modulator/set_validation")
        
        while not self.client_service.wait_for_service(timeout_sec=1.0):
            self.get_logger().warn("Aguardando o serviço /admittance_modulator/set_validation...")
        
        self.client_action = ActionClient(self, LlmContextual, 'multi_agent_contextual_action')
        self.user_input = ""

    #Chamada do serviço que muda o modo de fucionamento do andador.
    def send_service_request(self, activation_flag: bool):
            request = SetBool.Request()
            request.data = activation_flag
            self.last_mode = activation_flag

            try:
                future = self.client_.call_async(request)
                future.add_done_callback(self.service_response_callback)

            except Exception as e:
                self.get_logger().error(f"Failed to send service request: {e}")
                self.last_mode = None

    #Callback da execução do serviço de alteração do modo de funcionamento do andador.
    def service_response_callback(self, future):
            
        try:

            response = future.result()
            if response.success:
                    self.get_logger().info(f"Serviço executado: {response.message}")
            else:
                    self.get_logger().warn("Falha ao executar serviço.")
                    self.last_mode = None
  
        except Exception as e:
                
                self.get_logger().error(f"Erro na chamada do serviço: {str(e)}")
                self.last_mode = None

    #Chamada para o action de obtenção de rotas.
    def get_action_coordinates (self, user_command):

            #Envio da solicitação para obtenção das coordenadas.
            goal_msg = LlmContextual.Goal ()
            goal_msg.prompt = user_command
            self.get_logger().info(f'Solicitação enviada: {goal_msg.prompt}')
            self.client.wait_for_server()
            send_goal_future = self.client.send_goal_async(goal_msg, feedback_callback=self.feedback_callback)
            send_goal_future.add_done_callback(self.goal_response_callback)

        #Faz o processamento se o servidor aceitou ou não a solicitação.
    def goal_response_callback(self, future):

            goal_handle = future.result()
            #Verifica se o objetivo foi aceito ou rejeitado.
            if not goal_handle.accepted:
                self.get_logger().info('Objetivo rejeitado.')
                return
            self.get_logger().info('Objetivo aceito.')
            self.publish_state("Objetivo aceito, esperando a obetenção de um resultado...")
            
            # Solicitação do resultado.
            result_future = goal_handle.get_result_async()
            result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):

            result = future.result().result
            
            if not result.response.validate_request:
                self.get_logger().info("Invalid request, not publishing coordinates.")
                return

            self.get_logger().info(f'Final Response: {result.response.user_request}')
            self.get_logger().info(f'Goal Coordinates: x={result.response.goal_coordinates.x}, y={result.response.goal_coordinates.y}')
            
            pose_msg = Pose()
            pose_msg.position.x = float(result.response.goal_coordinates.x)
            pose_msg.position.y = float(result.response.goal_coordinates.y)
            print(pose_msg)
            
            self.get_logger().info("Fim do processo  de obteção das coordenadas...")

    def process_user_input(self):
            
            if not self.user_input:
                return
            
            print("ok")
            messages = [HumanMessage(content=self.user_input)]
            agent_result = agent.invoke({"messages": messages})
            agent_output = agent_result['messages'][-1].content

            if "free navigation" in agent_output.lower():
                self.send_service_request(True)
                

            elif "assisted navigation" in agent_output.lower():
                self.send_service_request(False)
                
                coordinates = self.create_routing_walker(self.user_input)
            
            print (coordinates)
            self.user_input = ""

    def user_input_callback(self, input_text: str):
            
            self.user_input = input_text

def main(args=None):

    rclpy.init(args=args)
    walker_llm_controller = OllamaLLM()
    
    try:
        while rclpy.ok():
            user_input = input("You: ")
            if user_input.lower() in ['exit', 'quit', 'bye']:
                print("Goodbye!")
                break
            
            walker_llm_controller.user_input_callback(user_input)
            rclpy.spin_once(walker_llm_controller)
    
    except KeyboardInterrupt:
         pass
    
    finally:
        walker_llm_controller.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()





