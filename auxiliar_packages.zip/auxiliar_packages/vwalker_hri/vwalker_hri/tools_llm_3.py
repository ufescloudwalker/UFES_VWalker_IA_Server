import rclpy
from langchain_core.tools import tool


@tool
def mode_operation_decision(msg: str) -> bool:
    """
    Decides how to activate the walker based on the user's spoken commands.

    Args:
    msg (str): User's command.

    Returns:
    bool: True for free navigation, False for assisted navigation, None for unknown commands.
    """
    msg = msg.lower()

    if any(word in msg for word in ["free navigation", "free navigation", "free mode"]):
        return True
    
    elif any(word in msg for word in ["assisted navigation", "assisted navigation", "assisted mode"]):
        return False

    return None
