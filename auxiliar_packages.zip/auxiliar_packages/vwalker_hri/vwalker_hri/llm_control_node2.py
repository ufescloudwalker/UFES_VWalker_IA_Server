#!/usr/bin/env python3
from langchain.agents import Tool
from langchain_ollama import ChatOllama
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.callbacks.manager import CallbackManager
from langchain_core.prompts import ChatPromptTemplate
from langchain.agents import AgentExecutor, create_react_agent
from smart_walker_ai_msgs.action import LlmContextual
from templates_tools import control_agent_tool_prompt_template
from langchain_core.prompts import PromptTemplate
from rclpy.action import ActionClient
from langchain_core.tools import tool
from tools_llm_3 import mode_operation_decision
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from std_srvs.srv import SetBool
import joblib

callback_manager = CallbackManager([StreamingStdOutCallbackHandler()])

# Carrega o modelo de LLM utilizado
LLM_model = ChatOllama(
    model="qwen2.5:32b",
    temperature=0.4,
    num_predict=200,
    callback_manager=callback_manager,
    seed=None,
)

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are an intelligent assistant controlling a walker. Your task is to identify the intent behind a user message. When the message is about assisted navigation or free navigation, you should interpret this as a command to start moving the walker and provide an appropriate response. When the message is informal conversation, such as asking about the weather or how someone is doing, respond in a friendly manner and do not initiate navigation. If the sentence contains ambiguities, provide a response suggesting that you can help in any way."),
        ("human", "{input}"),
    ]
)

chain = prompt | LLM_model

class OllamaLLM(Node):
    def __init__(self) -> None:
        super().__init__("LLM_Control_Node")

        self.mode_function_tool = Tool(
            name="mode_operation_decision",
            func=mode_operation_decision,
            description="Decides how to activate the walker based on the user's spoken command. "
                        "Returns True for free navigation, False for assisted navigation, "
                        "None if the mode cannot be determined."
        )

        self.navigate_tool = Tool(
            name="create_routing_walker",
            func=self.create_routing_walker,  # Corrigido: função chamada diretamente
            description="Creates a route for the walker based on the user's navigation command."
                        "Input: A string command like 'go to the kitchen'. "
                        "Output: Success message or detailed error information."
        )

        prompt_template = control_agent_tool_prompt_template()
        agent_prompt = PromptTemplate.from_template(prompt_template)

        # Criação do agente usando ReAct
        self.agent = create_react_agent(
            llm=LLM_model,
            tools=[self.mode_function_tool, self.navigate_tool],
            prompt=agent_prompt
        )

        self.agent_executor = AgentExecutor(
            agent=self.agent,
            tools=[self.mode_function_tool, self.navigate_tool],
            handle_parsing_errors=True
        )

        self.publisher_ = self.create_publisher(String, 'ollama_node', 10)
        self.client_ = self.create_client(SetBool, "/admittance_modulator/set_validation")
        self.publisher_2 = self.create_publisher(String, 'user_command', 10)
        self.client = ActionClient(self, LlmContextual, 'multi_agent_contextual_action')

        while not self.client_.wait_for_service(timeout_sec=1.0):
            self.get_logger().warn("Aguardando o serviço /admittance_modulator/set_validation...")

        self.timer = self.create_timer(1.0, self.process_user_input)
        self.user_input = ""
        self.last_mode = None

    @tool
    def create_routing_walker(self, command: str) -> str:
        """
        Executes a call to the walker's autonomous route generation program.
        """
        if not hasattr(self, '_action_client'):
            self._action_client = ActionClient(self, LlmContextual, 'multi_agent_contextual_action')

        if not self._action_client.wait_for_server(timeout_sec=1.0):
            return "Action server not available, please try again later."

        goal_msg = LlmContextual.Goal()
        goal_msg.prompt = command

        self.get_logger().info(f'Sending goal: {goal_msg.prompt}')

        self._send_goal_future = self._action_client.send_goal_async(goal_msg)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

        return f"Route creation request sent with command: '{command}'"

    # Função para enviar uma solicitação de troca de modo de funcionamento
    def send_service_request(self, activation_flag: bool):
        request = SetBool.Request()
        request.data = activation_flag
        self.last_mode = activation_flag

        try:
            future = self.client_.call_async(request)
            future.add_done_callback(self.service_response_callback)

        except Exception as e:
            self.get_logger().error(f"Failed to send service request: {e}")
            self.last_mode = None

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('Goal was rejected!')
            return

        self.get_logger().info('Goal accepted!')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info(f'Result: {result}')

    def service_response_callback(self, future):
        try:
            response = future.result()

            if response.success:
                self.get_logger().info(f"Serviço executado: {response.message}")
            else:
                self.get_logger().warn("Falha ao executar serviço.")
                self.last_mode = None

        except Exception as e:
            self.get_logger().error(f"Erro na chamada do serviço: {str(e)}")
            self.last_mode = None

    # Processa a entrada do usuário e gera uma resposta usando o modelo
    def process_user_input(self):
        if not self.user_input:
            return

        self.get_logger().info(f"User input: {self.user_input}")

        cmd_msg = String()
        cmd_msg.data = self.user_input
        self.publisher_2.publish(cmd_msg)

        # Invoca o agente com o novo formato
        agent_result = self.agent_executor.invoke({
            "input": self.user_input,
            "agent_scratchpad": ""
        })

        agent_output = agent_result.get('output', '')
        self.get_logger().info(f"Agent output: {agent_output}")

        resp_msg = String()
        resp_msg.data = agent_output
        self.publisher_.publish(resp_msg)

        if "free navigation" in agent_output.lower():
            self.send_service_request(True)
            self.get_logger().info("Free navigation mode activated")
        elif "assisted navigation" in agent_output.lower():
            self.send_service_request(False)
            self.get_logger().info("Assisted navigation mode activated")

        self.user_input = ""

    def user_input_callback(self, input_text: str):
        self.user_input = input_text

def main(args=None):
    rclpy.init(args=args)
    node = OllamaLLM()
    while rclpy.ok():
        user_input = input("You: ")
        if user_input.lower() in ['exit', 'quit', 'bye']:
            print("Goodbye!")
            break
        node.user_input_callback(user_input)

        while node.user_input:
            rclpy.spin_once(node, timeout_sec=0.1)

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
