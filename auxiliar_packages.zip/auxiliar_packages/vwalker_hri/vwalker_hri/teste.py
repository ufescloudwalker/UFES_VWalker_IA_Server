#!/usr/bin/env python3
from langchain.agents import Tool
from langchain_ollama import ChatOllama
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.callbacks.manager import CallbackManager
from langchain_core.prompts import ChatPromptTemplate
from langchain.agents import AgentExecutor, create_react_agent
from templates_tools import control_agent_tool_prompt_template
from tools_llm import action_decision
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from std_srvs.srv import SetBool
import joblib


callback_manager = CallbackManager([StreamingStdOutCallbackHandler()])

action_tool = Tool(
    name="action_decision",
    func=action_decision,
    description="Decides how to activate the walker based on the user's spoken command. "
                "Input: A string command. Output: 'Assisted Navigation' or 'Free Navigation'."
)

#Carrega o modelo de LLM utilizado.
LLM_model = ChatOllama(
    model="qwen2.5:32b",  
    temperature=0.4,      
    num_predict=200,     
    callback_manager=callback_manager,  
    seed=None,            
)

#Criação do agente usando ReAct:
agent = create_react_agent(
    llm=LLM_model,
    tools=[action_tool], 
    prompt= control_agent_tool_prompt_template()
)

agent_executor = AgentExecutor(agent=agent, tools= [action_tool], handle_parsing_errors=True)

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are an intelligent assistant controlling a walker. Your task is to identify the intent behind a user message. When the message is about assisted navigation or free navigation, you should interpret this as a command to start moving the walker and provide an appropriate response. When the message is informal conversation, such as asking about the weather or how someone is doing, respond in a friendly manner and do not initiate navigation. If the sentence contains ambiguities, provide a response suggesting that you can help in any way."),  
        ("human", "{input}"),                      
    ]
)

chain = prompt | LLM_model

class OllamaLLM(Node):
    def __init__(self) -> None:
        super().__init__("LLM_Control_Node")
    
        self.publisher_ = self.create_publisher(String, 'ollama_node', 10) 
        self.client_ = self.create_client(SetBool, "/admittance_modulator/set_validation") #Cria um clinte para o controlador de multi_admitancia.
        self.publisher_2 = self.create_publisher (String,'user_command',10)
        while not self.client_.wait_for_service(timeout_sec=1.0): #Limita a conversa do usuário com o LLM para se somente o serviço estiver disponível.
            self.get_logger().warn("Aguardando o serviço /admittance_modulator/set_validation...")
        
        
        self.timer = self.create_timer(1.0, self.process_user_input) #set um tempo para envio do pedido e execução do serviço.
        self.user_input = ""

    #Função para enviar uma solicitação de troca de modo dde funcionamento.    
    def send_service_request(self, activation_flag: bool):
        
        request = SetBool.Request()
        request.data = activation_flag

        future = self.client_.call_async(request)
        future.add_done_callback(self.service_response_callback)

    #Função de verificação para a correta execução do serviço.
    def service_response_callback(self, future):
        try:
            response = future.result()
            if response.success:
                self.get_logger().info(f"Serviço executado: {response.message}")
            else:
                self.get_logger().warn("Falha ao executar serviço.")
        except Exception as e:
            self.get_logger().error(f"Erro na chamada do serviço: {str(e)}")

    
    #Processa a entrada do usuário e gera uma resposta usando o modelo
    
    def process_user_input(self):
       
        if self.user_input:
            #self.get_logger().info(f"You: {self.user_input}")
            result = chain.invoke({"input": self.user_input})
            bot_response = getattr(result, 'text', str(result))  # Garante que seja uma string
            bot_response = str(bot_response).strip() 
       
        if not bot_response:
            self.get_logger().warn("Resposta do modelo vazia! Publicação ignorada.")
            return  # Evita publicar uma mensagem inválida

        self.publisher_.publish(String(data=bot_response))

        #Cria uma chamada para tool com o classiicador de frases.
        decision = agent_executor.invoke({"input": self.user_input,"agent_scratchpad": "","tools": action_tool.description,"tool_names": action_tool.name})
        White_rabbit = decision ['output']
        
        print("\n",White_rabbit)
        print("calling...")
           
                
        if White_rabbit == "Assisted Navigation":
                self.publisher_2.publish(String(data= self.user_input))        
                self.send_service_request(False)
                self.get_logger().info(f"Ativando navegação assistida")
                    
        if White_rabbit == "Free Navigation":
                        self.send_service_request(True)
                        self.get_logger().info(f"Ativando navegação livre")
                
        self.user_input = ""  

    #Callback para atualizar a entrada do usuário
    def user_input_callback(self, input_text: str):
        
        self.user_input = input_text

def main(args=None):
    rclpy.init(args=args)
    node = OllamaLLM()
    while rclpy.ok():
        user_input = input("You: ")
        if user_input.lower() == 'exit':
            print("Goodbye!")
            break
        node.user_input_callback(user_input)
        
        while node.user_input:
        
            rclpy.spin_once(node, timeout_sec= 0.1) 

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()